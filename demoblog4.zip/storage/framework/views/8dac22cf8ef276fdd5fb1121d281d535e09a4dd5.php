<!-- Navigation-->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <!--logo-->
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('front_assets/img/logo-dark.png')); ?>" alt="" class="logo-dark">
                <img src="<?php echo e(asset('front_assets/img/logo-white.png')); ?>" alt="" class="logo-white">
            </a>
        </div>

        <!--navbar-collapse-->
        <div class="collapse navbar-collapse" id="main_nav">
            <ul class="navbar-nav ml-auto mr-auto">


                <li class="nav-item dropdown">
                    <a class="nav-link  dropdown-toggle" href="#" data-toggle="dropdown"> Category </a>
                    <ul class="dropdown-menu fade-up">

                        <?php
                        $menu_cats = categoriesTop(6);
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $menu_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('front.posts-by-category', $cat->category_slug)); ?>"><span><?php echo e($cat->category_name); ?></span></a> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('front.category-all')); ?>"><span>All Categories</span></a> </li>

                    </ul>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('front.posts-all')); ?>"> All Posts </a>
                </li>
            </ul>
        </div>
        <!--/-->

        <!--navbar-right-->
        <div class="navbar-right ml-auto">
            <div class="social-icones">
                <ul class="list-inline">

                    <?php if(session('LOGIN') === true): ?>
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" target="_blank"><i class="fas fa-tachometer-alt"></i></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt"></i></a>
                    </li>
                    <?php else: ?>
                    <li>
                        <a href="<?php echo e(route('user-login')); ?>"><i class="fas fa-lock"></i></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('user-register')); ?>"><i class="fas fa-user"></i></a>
                    </li>
                    <?php endif; ?>

                </ul>
            </div>
            <div class="theme-switch-wrapper">
                <label class="theme-switch" for="checkbox">
                    <input type="checkbox" id="checkbox" />
                    <span class="slider round ">
                        <i class="far  fa-sun icon-light"></i>
                        <i class="far fa-moon icon-dark"></i>
                    </span>
                </label>
            </div>

            <div class="search-icon">
                <i class="far fa-search"></i>
            </div>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main_nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </div>
</nav><?php /**PATH F:\laravel\demoblog4\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>