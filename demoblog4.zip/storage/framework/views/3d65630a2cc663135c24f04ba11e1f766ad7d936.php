

<?php $__env->startSection('content'); ?>
<!-- Start Post List Wrapper  -->
<div class="axil-post-list-area axil-section-gap bg-color-white">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-xl-8">
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- Start Post List  -->
                <div class="content-block post-list-view mt--30">
                    <div class="post-thumbnail">
                        <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>">
                            <img src="<?php echo e(asset('storage/media/post/'. $post->post_image)); ?>" alt="Post Images">
                        </a>
                    </div>
                    <div class="post-content">
                        <div class="post-cat">
                            <div class="post-cat-list">
                                <a class="hover-flip-item-wrapper" href="<?php echo e(route('front.posts-by-category', $post->category_slug)); ?>">
                                    <span class="hover-flip-item">
                                        <span data-text="<?php echo e($post->category_name); ?>"><?php echo e($post->category_name); ?></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <h4 class="title"><a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>"><?php echo e(Str::limit($post->post_title, 50)); ?></a></h4>
                        <div class="post-meta-wrapper">
                            <div class="post-meta">
                                <div class="content">
                                    <h6 class="post-author-name">
                                        <a class="hover-flip-item-wrapper" href="#">
                                            <span class="hover-flip-item">
                                                <span data-text="<?php echo e($post->name); ?>"><?php echo e($post->name); ?></span>
                                            </span>
                                        </a>
                                    </h6>
                                    <ul class="post-meta-list">
                                        <li><?php echo e(Carbon\Carbon::parse($post->created_at)->toDayDateTimeString()); ?></li>
                                        <!-- <li>3 min read</li> -->
                                    </ul>
                                </div>
                            </div>
                            <ul class="social-share-transparent justify-content-end">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fas fa-link"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- End Post List  -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="content-block post-list-view mt--30">
                    <h2>No Posts Found</h2>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-4 col-xl-4 mt_md--40 mt_sm--40">
                <!-- Start Sidebar Area  -->
                <div class="sidebar-inner">

                    <!-- Start Single Widget  -->
                    <div class="axil-single-widget widget widget_instagram mb--30">
                        <h5 class="widget-title">Instagram</h5>
                        <!-- Start Post List  -->
                        <ul class="instagram-post-list-wrapper">
                            <li class="instagram-post-list">
                                <a href="#">
                                    <img src="<?php echo e(asset('front_assets/images/small-images/instagram-01.jpg')); ?>" alt="Instagram Images">
                                </a>
                            </li>
                            <li class="instagram-post-list">
                                <a href="#">
                                    <img src="<?php echo e(asset('front_assets/images/small-images/instagram-02.jpg')); ?>" alt="Instagram Images">
                                </a>
                            </li>
                            <li class="instagram-post-list">
                                <a href="#">
                                    <img src="<?php echo e(asset('front_assets/images/small-images/instagram-03.jpg')); ?>" alt="Instagram Images">
                                </a>
                            </li>
                            <li class="instagram-post-list">
                                <a href="#">
                                    <img src="<?php echo e(asset('front_assets/images/small-images/instagram-04.jpg')); ?>" alt="Instagram Images">
                                </a>
                            </li>
                            <li class="instagram-post-list">
                                <a href="#">
                                    <img src="<?php echo e(asset('front_assets/images/small-images/instagram-05.jpg')); ?>" alt="Instagram Images">
                                </a>
                            </li>
                            <li class="instagram-post-list">
                                <a href="#">
                                    <img src="<?php echo e(asset('front_assets/images/small-images/instagram-06.jpg')); ?>" alt="Instagram Images">
                                </a>
                            </li>
                        </ul>
                        <!-- End Post List  -->
                    </div>
                    <!-- End Single Widget  -->
                </div>
                <!-- End Sidebar Area  -->



            </div>
        </div>
    </div>
</div>
<!-- End Post List Wrapper  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog2\resources\views/frontend/post-search.blade.php ENDPATH**/ ?>