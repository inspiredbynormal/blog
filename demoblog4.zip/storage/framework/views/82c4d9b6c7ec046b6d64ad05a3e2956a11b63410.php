

<?php $__env->startSection('breadcrumb'); ?>
<!-- breadcrumb-area start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_box text-center">
                    <!-- <h2 class="breadcrumb-title">@title</h2> -->
                    <!-- breadcrumb-list start -->
                    <ul class="breadcrumb-list">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Register</li>
                    </ul>
                    <!-- breadcrumb-list end -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb-area end -->
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="login-register-page-area section-space--ptb_80">
    <div class="container">
        <div class="row ">
            <div class="col-lg-6 m-auto">
                <div class="login-content">

                    <div class="login-header mb-40">
                        <h3 class="mb-2">Register</h3>
                        <h5>Become a member</h5>
                    </div>

                    <div class="">
                        <?php if(session('msg')): ?>
                        <div class="alert alert-<?php echo e(session('type') == 'error' ? 'danger' : 'success'); ?>">
                            <?php echo e(session('msg')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>


                    <form method="POST" action="<?php echo e(route('user-register-submit')); ?>">
                        <?php echo csrf_field(); ?>
                        <input placeholder="Enter Name" type="text" id="name" name="name" required value="<?php echo e(old('name')); ?>">
                        <input placeholder="Enter Email" type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                        <input placeholder="Enter Password" type="password" id="password" name="password" autocomplete="off" required>


                        <button type="submit" class="btn-primary btn-large">Register Now</button>
                        <div class="member-register mt-5">
                            <p> A member? <a href="<?php echo e(route('user-login')); ?>"> Log in now</a></p>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog3\resources\views/frontend/user/register.blade.php ENDPATH**/ ?>