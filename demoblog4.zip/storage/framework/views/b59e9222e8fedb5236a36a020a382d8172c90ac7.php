<footer class="main-footer">
    <strong>Copyright &copy; <?php echo date('Y') ?> <a href="#">smsolutions.in</a></strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0
    </div>
</footer><?php /**PATH F:\laravel\demoblog2\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>