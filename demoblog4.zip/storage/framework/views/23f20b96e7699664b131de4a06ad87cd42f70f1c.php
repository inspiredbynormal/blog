



<?php $__env->startSection('content'); ?>
<section class="categorie-section mt-90">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="categorie-title">
                    <small>
                        <a href="<?php echo e(url('/')); ?>">Home</a>

                        <span class="arrow_carrot-right"></span> Blog
                    </small>
                    <h3>Category :
                        <span> <?php echo e($category->category_name); ?></span>
                    </h3>

                </div>
            </div>
        </div>
    </div>
</section>

<section class="mb-70">
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-6 ">
                <div class="post-list">
                    <div class="image">
                        <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>">
                            <img src="<?php echo e(asset('storage/media/post/'. $post->post_image)); ?>" alt="">
                        </a>
                    </div>
                    <div class="content">
                        <a href="<?php echo e(route('front.posts-by-category', $post->category->category_slug)); ?>" class="categorie">
                            <i class="icon_circle-slelected"></i><?php echo e($post->category->category_name); ?>

                        </a>
                        <h5>
                            <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>"><?php echo e(Str::limit($post->post_title, 50)); ?></a>
                        </h5>

                        <div class="meta">
                            <ul class="list-inline">
                                <li>
                                    <a href="#"><?php echo e($post->user->name); ?></a>
                                </li>
                                <li class="dot"></li>
                                <li><?php echo e(Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <h6>No posts found in this category</h6>
            </div>
            <?php endif; ?>
        </div>
        <div class="row mt-20">
            <div class="col-lg-12">
                <div class="load-posts text-center">
                    <?php echo e($posts->links()); ?>

                    <!-- <a href="#" class="btn-custom"> More posts</a> -->
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog4\resources\views/frontend/posts-by-category.blade.php ENDPATH**/ ?>