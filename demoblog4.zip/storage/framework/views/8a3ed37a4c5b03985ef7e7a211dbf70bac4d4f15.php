<!-- Start Mobile Menu Area  -->
<div class="popup-mobilemenu-area">
    <div class="inner">
        <div class="mobile-menu-top">
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>">
                    <img class="dark-logo" src="<?php echo e(asset('front_assets/images/logo/logo-b.png')); ?>" alt="Logo Images">
                    <img class="light-logo" src="<?php echo e(asset('front_assets/images/logo/logo-w.png')); ?>" alt="Logo Images">
                </a>
            </div>
            <div class="mobile-close">
                <div class="icon">
                    <i class="fal fa-times"></i>
                </div>
            </div>
        </div>
        <ul class="mainmenu">
            <li class="menu-item-has-children"><a href="#">Categories</a>
                <ul class="axil-submenu">
                    <?php
                    $menu_cats = categories();
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $menu_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li><a href="<?php echo e(route('front.posts-by-category', $cat->category_slug)); ?>"><?php echo e($cat->category_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>
            </li>

            <li><a href="<?php echo e(route('front.category-all')); ?>">More Categories</a></li>
            <li><a href="<?php echo e(route('front.posts-all')); ?>">All Posts</a></li>
        </ul>

    </div>
</div>
<!-- End Mobile Menu Area  --><?php /**PATH F:\laravel\demoblog2\resources\views/frontend/layouts/mobile-menu.blade.php ENDPATH**/ ?>