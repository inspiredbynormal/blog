

<?php $__env->startSection('content'); ?>
<!-- Blog Details Wrapper Start -->
<div class="blog-details-wrapper section-space--ptb_80">
    <div class="container">
        <div class="row row--17">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <!-- Single Following Post Start -->
                <div class="single-following-post" data-aos="fade-up">
                    <a href="<?php echo e(route('front.posts-by-category', $category->category_slug)); ?>" class="following-post-thum">
                        <img src="<?php echo e(asset('storage/media/category/'. $category->category_image)); ?>" alt="">
                    </a>
                    <div class="following-post-content">
                        <h5 class="following-blog-post-title">
                            <a href="<?php echo e(route('front.posts-by-category', $category->category_slug)); ?>"><?php echo e($category->category_name); ?>

                            </a>
                        </h5>
                    </div>
                </div><!-- Single Following Post End -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <h2>No Posts Found</h2>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div> <!-- Blog Details Wrapper End -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog3\resources\views/frontend/category-all.blade.php ENDPATH**/ ?>