

<?php $__env->startSection('main_content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="">
                    <?php if(session('msg')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('msg')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="card">
                    <div class="card-header">
                        <div class="list-header">
                            <h3 class="card-title">Post List</h3>
                            <a href="<?php echo e(route('admin.post.create')); ?>" class="btn bg-gradient-primary btn-sm"><i class="fas fa-plus"></i> Add New Post</a>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="listTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Post Title</th>
                                    <th>Category</th>
                                    <th>Post Image</th>
                                    <th>Post Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($post->post_title); ?></td>
                                    <td><?php echo e($post->category->category_name); ?></td>
                                    <td><img src="<?php echo e(($post->post_image != NULL) ? asset('storage/media/post/'. $post->post_image) : ''); ?>" alt="" class="img-fluid list-image"></td>
                                    <td><span class="badge <?php echo e(($post->status == 'publish') ?  'badge-success' : 'badge-danger'); ?>"><?php echo e($post->status); ?></span></td>
                                    <td>
                                        <div class="action_btn_box">
                                            <a href="<?php echo e(route('admin.post.edit', [$post->id])); ?>" class="btn bg-gradient-primary btn-sm"><i class="fas fa-edit"></i></a>
                                            <form action="<?php echo e(route('admin.post.destroy', [$post->id])); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" href="#" class="btn btn-sm bg-gradient-danger"><i class="fas fa-trash-alt"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php
                                $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No Post Found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>

                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog4\resources\views/admin/post/index.blade.php ENDPATH**/ ?>