<header class="sticky-header">
    <div class="container-fluid">
        <div class="d-flex align-items-center justify-content-between">
            <div class="site-logo">
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('front_assets/img/logo.png')); ?>" alt="Genial"></a>
            </div>
            <div class="header-right">
                <div class="search-area">
                    <a href="javascript:void(0)" class="search-btn"><i class="fas fa-search"></i></a>
                    <div class="search-form">
                        <a href="#" class="search-close"><i class="fal fa-times"></i></a>
                        <form action="<?php echo e(route('front.search-posts')); ?>" method="GET">
                            <input type="search" name="search" placeholder="Type here to search">
                        </form>
                        <div class="search-overly"></div>
                    </div>
                </div>

                <div class="offcanvas-panel">
                    <a href="javascript:void(0)" class="panel-btn">
                        <span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    </a>
                    <div class="panel-overly"></div>
                    <div class="offcanvas-items">
                        <!-- Navbar Toggler -->
                        <a href="javascript:void(0)" class="panel-close">
                            Back <i class="fa fa-angle-right" aria-hidden="true"></i>
                        </a>

                        <ul class="offcanvas-menu">
                            <li><a href="<?php echo e(route('front.category-all')); ?>">Categories</a></li>
                            <li><a href="<?php echo e(route('front.posts-all')); ?>">All Posts</a></li>

                            <?php if(session('LOGIN') === true): ?>
                            <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                            <?php else: ?>
                            <li><a href="<?php echo e(route('user-login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('user-register')); ?>">Register</a></li>
                            <?php endif; ?>


                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH F:\laravel\demoblog\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>