




<?php $__env->startSection('content'); ?>

<!--contact-->
<section class="contact mb-70" style="margin-top: 91px;">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="login-header mb-40 mt-5">
                    <h5>Register Now</h5>
                </div>

                <div class="">
                    <?php if(session('msg')): ?>
                    <div class="alert alert-<?php echo e(session('type') == 'error' ? 'danger' : 'success'); ?>">
                        <?php echo e(session('msg')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-8 offset-lg-2">
                <form method="POST" action="<?php echo e(route('user-register-submit')); ?>" class="form" id="main_contact_form">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" name="name" id="name" class="form-control" placeholder="Name*" required="required" value="<?php echo e(old('name')); ?>">
                    </div>

                    <div class="form-group">
                        <input type="email" name="email" id="email" class="form-control" placeholder="Email*" required="required" value="<?php echo e(old('email')); ?>">
                    </div>

                    <div class="form-group">
                        <input type="password" id="password" name="password" autocomplete="off" required="required" class="form-control" placeholder="Password*">
                    </div>

                    <button type="submit" name="submit" class="btn-custom">
                        Log in
                    </button>

                    <div class="member-register mt-5">
                        <p> Already member? <a href="<?php echo e(route('user-login')); ?>"> Login now</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog4\resources\views/frontend/user/register.blade.php ENDPATH**/ ?>