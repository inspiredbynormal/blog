

<?php $__env->startSection('content'); ?>

<!--hero-->
<section class="hero hero-2 hero-carousel d-flex align-items-center">
    <div class="container ">
        <div class="owl-carousel">
            <?php $__empty_1 = true; $__currentLoopData = $gallery_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row d-flex align-items-center">
                <div class="col-lg-5">
                    <div class="image">
                        <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>">
                            <img src="<?php echo e(asset('storage/media/post/'. $post->post_image)); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="post">
                        <a href="<?php echo e(route('front.posts-by-category', $post->category->category_slug)); ?>" class="categorie">
                            <i class="icon_circle-slelected"></i><?php echo e($post->category->category_name); ?>

                        </a>
                        <h3>
                            <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>"><?php echo e(Str::limit($post->post_title, 100)); ?></a>
                        </h3>
                        <p><?php echo e(Str::limit($post->post_short_desc, 100)); ?></p>
                        <div class="info">
                            <ul class="list-inline">
                                <li>
                                    <a href="#">
                                        <img src="<?php echo e(($post->user->avatar == NULL) ? asset('front_assets/img/user/no-user-image.jpg') : asset('storage/media/user/'. $post->user->avatar)); ?>" alt="">
                                    </a>
                                </li>
                                <li>
                                    <a href="#"><?php echo e($post->user->name); ?></a>
                                </li>
                                <li class="dot"></li>
                                <li><?php echo e(Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?></li>
                                <!-- <li class="dot"></li> -->
                                <!-- <li>5 min Read</li> -->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="row d-flex align-items-center">
                <div class="col-12">
                    No Posts found
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!--categories-->
<div class="categorie-section pt-60">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <ul class="cat-list">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li>
                        <a class="item" href="<?php echo e(route('front.posts-by-category', $category->category_slug)); ?>">
                            <div class="image">
                                <img src="<?php echo e(asset('storage/media/category/'. $category->category_image)); ?>" alt="">
                            </div>
                            <p><?php echo e($category->category_name); ?></p>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>

                </ul>
            </div>
        </div>
    </div>
</div>

<!--Posts-->
<section class="section mt-50 mb-70">
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-6">
                <div class="post-box">
                    <div class="image">
                        <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>">
                            <img src="<?php echo e(asset('storage/media/post/'. $post->post_image)); ?>" alt="">
                        </a>
                    </div>
                    <div class="content">
                        <a href="<?php echo e(route('front.posts-by-category', $post->category->category_slug)); ?>" class="categorie">
                            <i class="icon_circle-slelected"></i><?php echo e($post->category->category_name); ?>

                        </a>
                        <h5>
                            <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>"><?php echo e(Str::limit($post->post_title, 50)); ?></a>
                        </h5>

                        <div class="meta">
                            <ul class="list-inline">

                                <li>
                                    <a href="#"><?php echo e($post->user->name); ?></a>
                                </li>
                                <li class="dot"></li>
                                <li><?php echo e(Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog4\resources\views/frontend/home.blade.php ENDPATH**/ ?>