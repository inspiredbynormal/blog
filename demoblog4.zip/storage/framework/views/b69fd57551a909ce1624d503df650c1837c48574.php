

<?php $__env->startSection('content'); ?>
<!--post-single-top-->
<section class="post-single-top d-flex align-items-center">
    <div class="container ">
        <div class="row ">
            <div class="col-lg-12">
                <div class="post-single-header">
                    <div class="row d-flex align-items-center">
                        <div class="col-lg-7 b-order-2">
                            <div class="desc">
                                <a href="<?php echo e(route('front.posts-by-category', $post->category->category_slug)); ?>" class="categorie">
                                    <i class="icon_circle-slelected"></i><?php echo e($post->category->category_name); ?>

                                </a>
                                <h4><?php echo e($post->post_title); ?></h4>
                                <p><?php echo e($post->post_short_desc); ?>

                                </p>
                                <div class="info">
                                    <ul class="list-inline">
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo e(($post->user->avatar == NULL) ? asset('front_assets/img/user/no-user-image.jpg') : asset('storage/media/user/'. $post->user->avatar)); ?>" alt="">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#"><?php echo e($post->user->name); ?></a>
                                        </li>
                                        <li class="dot"></li>
                                        <li><?php echo e(Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?></li>

                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-5 b-order-1">
                            <div class="image">
                                <img src="<?php echo e(asset('storage/media/post/'. $post->post_image)); ?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--post-single-->
<section class="post-single">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 m-auto">
                <div class="post-single-body">
                    <div class="content">
                        <?php echo nl2br($post->post_desc); ?>

                    </div>
                </div>



                <!--author-->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="author  box bg-light mt-5">
                            <div class="image">
                                <a href="#" class="image">
                                    <img src="<?php echo e(($post->user->avatar == NULL) ? asset('front_assets/img/user/no-user-image.jpg') : asset('storage/media/user/'. $post->user->avatar)); ?>" alt="">
                                </a>
                            </div>
                            <div class="content">
                                <h5>
                                    <span>Hi, I'm <?php echo e($post->user->name); ?></span>
                                </h5>

                                <div class="social-icones">
                                    <ul class="list-inline">
                                        <li>
                                            <a href="#">
                                                <i class="fab fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fab fa-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fab fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fab fa-youtube"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fab fa-behance"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fab fa-dribbble"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <!--Related posts-->
                <div class="row mb-50">
                    <div class="col-12">
                        <h5 class="mb-30">Related Posts</h5>
                    </div>
                    <?php $__empty_1 = true; $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-6">
                        <div class="related-posts box bg-light ">
                            <div class="small-post ">
                                <div class="image">
                                    <a href="<?php echo e(route('front.blog-details', [$rpost->post_slug])); ?>">
                                        <img src="<?php echo e(asset('storage/media/post/'. $rpost->post_image)); ?>" alt="...">

                                    </a>

                                </div>

                                <div class="content">
                                    <p>
                                        <a href="<?php echo e(route('front.blog-details', [$rpost->post_slug])); ?>"><?php echo e($rpost->post_title); ?></a>
                                    </p>
                                    <small><span class="dot"></span> <?php echo e(Carbon\Carbon::parse($rpost->created_at)->diffForHumans()); ?></small>
                                </div>

                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <h6 class="text-left">No related post found</h6>
                    </div>
                    <?php endif; ?>
                </div>

                <!--Comments-->
                <div class="mb-100">
                    <h5 class="mb-30"><?php echo e(count($comments)); ?> Comments</h5>
                    <ul class="comments">
                        <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="comment-item">
                            <img src="<?php echo e(($comment->user->avatar == NULL) ? asset('front_assets/img/user/no-user-image.jpg') : asset('storage/media/user/'. $comment->user->avatar)); ?>" alt="">
                            <div class="content">
                                <ul class="info list-inline">
                                    <li><?php echo e($comment->user->name); ?></li>
                                    <li> - </li>
                                    <li><?php echo e(Carbon\Carbon::parse($comment->created_at)->diffForHumans()); ?></li>
                                </ul>
                                <p><?php echo nl2br($comment->comment_msg); ?></p>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </ul>
                    <!--Leave-comments-->
                    <h5 class="mb-30">Leave a Reply</h5>
                    <div id="comment_response"></div>
                    <?php if(session('LOGIN') == true): ?>
                    <form class="form" method="POST" id="commentFrmSubmit">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                        <p>Your email adress will not be published ,Requied fileds are marked*.</p>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <textarea name="comment_msg" id="comment_msg" cols="30" rows="5" class="form-control" placeholder="Message*" required="required"></textarea>
                                </div>
                            </div>
                            <?php if(session('ROLE') == 'admin'): ?>
                            <?php
                            $user = userDetails(session('ADMIN_ID'));
                            ?>

                            <?php elseif(session('ROLE') == 'editor'): ?>
                            <?php
                            $user = userDetails(session('EDITOR_ID'));
                            ?>
                            <?php endif; ?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="name" id="name" class="form-control" placeholder="Name*" required="required" value="<?php echo e($user->name); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Email*" required="required" value="<?php echo e($user->email); ?>" disabled>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <button type="submit" name="submit" class="btn-custom">
                                    Send Comment
                                </button>
                            </div>
                        </div>
                    </form>
                    <?php else: ?>
                    <p><a class="mt-3 p-3 btn-custom" href="<?php echo e(route('user-login')); ?>">Please login to write your comment</a></p>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('front_script'); ?>
<script>
    $(document).ready(function() {
        $("#commentFrmSubmit").on('submit', function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            $.ajax({
                url: "<?php echo e(route('user.comment.submit')); ?>",
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    $("#commentFrmSubmit").trigger("reset");

                    if (response.status === 'error') {
                        $("#comment_response").html(`<div class="alert alert-danger">${response.message}</div>`);
                    } else {
                        $("#comment_response").html(`<div class="alert alert-success">${response.message}</div>`);
                    }

                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            });
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog4\resources\views/frontend/blog-details.blade.php ENDPATH**/ ?>