<footer>
    <div class="footer-widgets-area">
        <div class="container container-1360">
            <div class="row">
                <div class="col-lg-12 col-sm-12 ml-auto">
                    <div class="widget newsletter-widget border-top">
                        <h4 class="widget-title mt-20">About Us</h4>

                        <p class="text-justify">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Harum soluta itaque dicta necessitatibus placeat. Hic voluptate alias qui nulla quas vitae nihil provident veniam. Cum nam iste molestiae aspernatur consequuntur sequi fuga atque architecto rem! Omnis dignissimos mollitia ut, rerum cupiditate tempore pariatur voluptatibus quas earum tenetur esse itaque culpa. Eveniet porro impedit commodi quod error quam repellat tempore vel quaerat corporis, iure nemo non debitis atque quas alias sequi soluta cupiditate ex veritatis molestias possimus! Vel, explicabo eaque mollitia exercitationem culpa placeat beatae accusamus consequuntur ipsam odio deserunt harum vero neque aut reiciendis porro iusto commodi eum adipisci omnis, veritatis quis expedita saepe? Voluptates ut eius saepe beatae? Deserunt incidunt deleniti eveniet placeat dolor reiciendis et magnam, id explicabo eius aliquam quasi dolore ipsa vel sint laudantium aut beatae totam, corrupti minima consectetur amet cum molestiae consequuntur. Sit, voluptatibus. Saepe quidem nemo porro temporibus repellat fuga nesciunt totam ut.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-copyright-section">
        <div class="container-fluid">
            <div class="d-flex justify-content-center">
                <p><span>Copyright</span> - <?php echo date('Y') ?> </p>
            </div>
        </div>
    </div>
</footer><?php /**PATH F:\laravel\demoblog\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>