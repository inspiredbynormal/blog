<div class="mobile-menu-overlay" id="mobile-menu-overlay">
    <div class="mobile-menu-overlay__inner">
        <div class="mobile-menu-overlay__header">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-6 col-8">
                        <!-- logo -->
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('front_assets/images/logo/logo.png')); ?>" class="img-fluid" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 col-4">
                        <!-- mobile menu content -->
                        <div class="mobile-menu-content text-end">
                            <span class="mobile-navigation-close-icon" id="mobile-menu-close-trigger"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mobile-menu-overlay__body">
            <nav class="offcanvas-navigation">
                <ul>

                    <li><a href="#"><span>About</span></a></li>
                    <li class="has-children">
                        <a href="#" onclick="return false;">Category</a>
                        <ul class="sub-menu">
                            <?php
                            $menu_cats = categoriesTop(6);
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $menu_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><a href="<?php echo e(route('front.posts-by-category', $cat->category_slug)); ?>"><span><?php echo e($cat->category_name); ?></span></a> </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('front.category-all')); ?>"><span>All Categories</span></a> </li>
                        </ul>
                    </li>

                    <li><a href="<?php echo e(route('front.posts-all')); ?>"><span>All Posts </span></a></li>
                    <li><a href="#"><span>Contact </span></a></li>
                </ul>
            </nav>
        </div>
    </div>
</div><?php /**PATH F:\laravel\demoblog4\resources\views/frontend/layouts/mobile-menu.blade.php ENDPATH**/ ?>