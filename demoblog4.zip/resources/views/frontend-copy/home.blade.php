@extends('frontend.layouts.master')

@section('content')

<!-- Hero Area Start -->
<div class="hero-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="hero-inner-area">
                    <!-- Hero Category Area Start -->
                    <div class="hero-category-area">
                        @php
                        $menu_cats = categories();
                        @endphp
                        @forelse($menu_cats as $cat)
                        <a href="{{route('front.posts-by-category', $cat->category_slug)}}" class="single-hero-category-item" data-aos="fade-up">
                            <img src="{{asset('storage/media/category/'. $cat->category_image)}}" alt="">
                            <div class="hero-category-inner-box">
                                <h3 class="title">{{$cat->category_name}}</h3>
                                <i class="icon icofont-long-arrow-right"></i>
                            </div>
                        </a>
                        @empty
                        @endforelse
                    </div><!-- Hero Category Area End -->
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia eligendi, neque dolorem explicabo incidunt voluptatum quis ratione doloremque tenetur autem distinctio! Sunt illo mollitia animi magni qui sed possimus culpa maiores, quisquam praesentium autem dicta? Dicta nisi ipsa ea deserunt quibusdam neque dignissimos. Modi, fugit. Inventore repellendus dignissimos earum doloribus provident nostrum libero laudantium quisquam! Facere nesciunt molestias excepturi enim distinctio at iste nam, ut, corrupti dicta quos! Cumque assumenda doloremque dolore quas placeat aspernatur reprehenderit at fugit voluptate, accusantium neque ab, perspiciatis debitis doloribus. Quis, accusantium? Ex similique molestiae amet totam voluptas porro atque provident quo sed accusamus! Libero consequuntur sunt quaerat obcaecati perspiciatis tenetur quasi at nulla sint minima quibusdam beatae dolor iste eveniet velit eos inventore, nihil modi dolorum? Omnis maiores placeat tempora nesciunt accusantium nostrum eius vel. Tempora officiis inventore sequi blanditiis accusamus optio alias, quis nulla repellat est nostrum nobis sunt suscipit, eos repellendus laborum quisquam minima facere maxime quos quo quas quidem consectetur fugit. Expedita debitis dolorum saepe optio aliquid dignissimos sapiente molestiae alias iure. Modi tempore quos doloribus expedita sit natus optio? Quas laboriosam iusto debitis rem consequuntur doloremque quam eligendi, tempora soluta praesentium. Ad optio ab repellendus, accusamus nisi perferendis. Atque, exercitationem repellendus neque nesciunt dolor provident officia quos aliquid laborum quis illum sed numquam labore mollitia nostrum, corporis sint ratione quasi explicabo perferendis sequi maiores nemo? Exercitationem voluptas harum cumque quis enim. Nisi, temporibus vero aliquam corrupti in illum odio illo exercitationem voluptate ab porro dicta autem? Accusantium iste similique in ad, minus velit quo qui modi totam laudantium molestias eos, inventore culpa consequatur facilis voluptas architecto expedita. Similique porro vitae omnis magnam laudantium commodi consequatur. Ea harum optio aliquid corrupti dolore? Corporis rem repudiandae sequi qui laborum. Vero impedit, voluptatem est tempora hic cupiditate ipsum architecto ut. Laborum eum quidem odit blanditiis. Perspiciatis, totam iste dolorem corporis quasi ipsam ducimus earum consequatur nulla quia quos magnam laudantium dolor, necessitatibus debitis animi, explicabo unde repellendus. Dicta, in quidem! Recusandae voluptate eaque, aliquam eius amet suscipit repellat? Tempora saepe laudantium reiciendis enim unde vero maxime molestias, sit mollitia voluptas dolorem ut assumenda porro natus quasi similique culpa optio dolore aliquam. Accusantium suscipit quos, facere quas unde, ab rem consequuntur dolorem ipsum quidem molestias. Explicabo harum tenetur molestiae a perspiciatis totam deleniti quod rerum perferendis maxime reiciendis aspernatur maiores, labore odit temporibus voluptas repellat nihil, tempore cumque suscipit iusto. Doloribus aliquid nostrum omnis. At, sequi pariatur. Amet eius odio animi quam sapiente, illum ad corporis adipisci qui non libero cum, incidunt modi repellat repudiandae aliquam perspiciatis harum dolorem dolor nemo, maiores eos! Aliquid, sapiente quam quis facere error provident voluptate esse perspiciatis magnam aliquam quia ullam quod, explicabo nisi neque quos itaque molestiae consequatur libero sed, quaerat aperiam iure. Provident, dolore. Vero, magni culpa dolores animi quas officia accusamus sequi et obcaecati quidem, minus dolorem veritatis similique, saepe ipsam qui aut necessitatibus facilis! Veniam ipsa odit tempora unde fugit maiores. Voluptatum expedita veniam quaerat, aliquid enim recusandae accusantium. Excepturi dolores impedit soluta hic quos ipsum nostrum sapiente, assumenda iste totam architecto deleniti necessitatibus repudiandae consectetur recusandae tempore, debitis similique exercitationem praesentium eveniet veritatis libero? Dolores illo voluptas voluptates incidunt et blanditiis quas eligendi. Ea recusandae magnam, accusamus repudiandae nobis eaque suscipit quas sed iure reiciendis in optio doloremque iste quia. Delectus saepe tenetur molestiae doloribus in possimus, eius eos, culpa odio tempore minus, recusandae quae. Id dicta iusto fuga ea, enim quibusdam modi quod laudantium repellat necessitatibus quo cupiditate eos distinctio veritatis, eligendi aliquid odit minima, dolorum possimus? Voluptatum, illo voluptates. Nihil cumque reiciendis quisquam maiores incidunt commodi dolores, porro nam eius! Voluptatem, iste? Sed, laudantium quibusdam sint tempora cum delectus quis quia quo dolor ducimus officia, debitis similique ratione voluptatum deserunt fugiat provident error assumenda fuga accusamus. Animi reiciendis explicabo iure repellendus voluptatibus perferendis exercitationem mollitia ipsam tempore odit, voluptatum sit sint asperiores minima dolorem neque vitae! Impedit vitae incidunt non ad. Magni suscipit pariatur odit eius laboriosam sunt esse natus facilis placeat tenetur vel fugit amet, dicta, earum animi modi consequatur expedita eum iusto velit adipisci repellat molestiae facere quasi. Ullam, dicta maiores velit repellendus earum, perferendis eligendi laboriosam iusto vel libero natus dolores architecto. Omnis delectus neque similique, commodi voluptatum possimus at tempora iusto esse inventore in error corrupti? Facilis, perspiciatis! Dolores, distinctio optio illum sed repellat nam. Sunt et excepturi, enim ipsa unde saepe blanditiis repellendus amet voluptatum, fugiat, aperiam quaerat sit provident molestias maiores nisi in! Quisquam, quam neque. Quas facere, exercitationem voluptates ut provident minima velit maiores reprehenderit vel rem magni. Quis obcaecati at earum maiores sunt molestias non sapiente ipsa! Cumque natus dolore architecto incidunt voluptatem eaque quod laborum amet nobis delectus, expedita corrupti perferendis ipsa. Molestiae dolor magnam beatae in similique accusamus nihil natus illum dicta quod eligendi, provident error laboriosam at totam odio impedit omnis! Odit quasi quos iste ab cum deleniti soluta hic animi. Tempora quod vitae quas nesciunt? Doloribus enim dolore beatae, dolorum expedita possimus in odio atque corrupti voluptatem dolorem esse voluptas reprehenderit odit illum! Repellendus ut alias impedit, neque quaerat ab quo numquam tenetur cupiditate, eum quisquam quasi maxime consectetur. Esse modi provident nam commodi qui odit aperiam voluptatem natus quidem ad similique, alias accusantium quasi illum possimus beatae debitis autem nesciunt veritatis sint? Praesentium eligendi porro omnis recusandae neque possimus molestias sunt blanditiis. Qui eum suscipit rerum, laboriosam magnam facere neque enim autem voluptate facilis! Impedit doloribus facere commodi recusandae placeat nobis corporis, repellat soluta atque iure omnis in praesentium similique maiores labore officia laborum explicabo officiis facilis debitis ipsum eius provident, pariatur aliquid. Enim vero quos iusto accusamus ad eum hic harum. Alias ea ex, nam reiciendis enim ducimus sint quo aliquid reprehenderit inventore animi commodi similique nobis quas dolore veniam explicabo dignissimos non deserunt veritatis et! Libero, aliquam possimus! Sed quasi, eaque voluptatem vel voluptas quo. Sed quos repellat minima quas asperiores eligendi ratione eius aliquam libero ducimus, excepturi cum beatae. Quaerat ipsum possimus facere labore, aliquid ea, eius rerum, illo a dolor quos aspernatur. Quisquam, vero.
                    <!-- Hero Banner Area Start -->
                    <div class="hero-banner-area" data-aos="fade-up">
                        @forelse($gallery_post as $post)
                        <a class="mt-3" href="{{route('front.blog-details', [$post->post_slug])}}">
                            <img src="{{asset('storage/media/post/'. $post->post_image)}}" alt="">
                        </a>
                        @empty
                        @endforelse
                    </div>
                    <!-- Hero Banner Area End -->

                    <div class="hero-blog-post">
                        @forelse($gallery_post as $post)
                        <!-- Single-hero-blog-post Start -->
                        <div class="single-hero-blog-post" data-aos="fade-up">
                            <div class="hero-blog-post-top">
                                <div class="hero-blog-post-category">
                                    <a href="{{route('front.posts-by-category', $post->category->category_slug)}}" class="marketing">{{$post->category->category_name}}</a>
                                </div>
                                <div class="hero-blog-post-author">
                                    By <a href="#">{{$post->user->name}}</a>
                                </div>
                            </div>
                            <h3 class="hero-blog-post-title">
                                <a href="{{route('front.blog-details', [$post->post_slug])}}">{{Str::limit($post->post_title, 45)}}
                                </a>
                            </h3>
                            <p class="post-short-details">
                                {{Str::limit($post->post_short_desc, 60)}}
                            </p>
                            <div class="hero-blog-post-meta">
                                <div class="post-meta-left-side">
                                    <span class="post-date">
                                        <i class="icofont-ui-calendar"></i>
                                        <a href="#">{{ Carbon\Carbon::parse($post->created_at)->diffForHumans() }}</a>
                                    </span>
                                </div>
                                <div class="post-meta-right-side">
                                    <a href="#"><img src="{{asset('front_assets/images/icons/small-bookmark.png')}}" alt="" /></a>
                                    <a href="#"><img src="{{asset('front_assets/images/icons/heart.png')}}" alt="" /></a>
                                </div>
                            </div>
                        </div><!-- Single-hero-blog-post End -->
                        @empty
                        @endforelse
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> <!-- Hero Area End -->


<div class="bg-gray-1">
    <!-- Trending Topic Area Start -->
    <div class="trending-topic-area section-space--ptb_80">
        <div class="container">
            <div class="row align-items-center">
                <div class="trending-topic-section-title">
                    <h3>Trending Topic</h3>
                    <div class="trending-topic-navigation mt-30">
                        <div class="trending-topic-button-prev navigation-button"><i class="icofont-long-arrow-left"></i></div>
                        <div class="trending-topic-button-next navigation-button"><i class="icofont-long-arrow-right"></i></div>
                    </div>
                </div>
                <div class="trending-topic-item-wrap">
                    <div class="swiper-container trending-topic-slider-active">
                        <div class="swiper-wrapper">
                            @forelse($categories as $category)
                            <div class="swiper-slide" data-aos="fade-up">
                                <div class="single-trending-topic-item">
                                    <a href="{{route('front.posts-by-category', $category->category_slug)}}">
                                        <img src="{{asset('storage/media/category/'. $category->category_image)}}" alt="">
                                        <h4 class="title">{{$category->category_name}}</h4>
                                    </a>
                                </div>
                            </div>
                            @empty
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- Trending Topic Area End -->
</div>


<!-- Recent Reading List Area Start -->
<div class="recent-reading-list-area section-space--pb_80">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="recent-reading-header">
                    <div class="section-title">
                        <h3>Recent Reading List</h3>
                    </div>
                    <div class="recent-reading-slider-navigation mt-2 mb-2">
                        <div class="recent-reading-button-prev navigation-button"><i class="icofont-long-arrow-left"></i></div>
                        <div class="recent-reading-button-next navigation-button"><i class="icofont-long-arrow-right"></i></div>
                    </div>

                </div>
            </div>
        </div>
        <div class="swiper-container recent-reading-slider-active">
            <div class="swiper-wrapper">
                @forelse($postsGroups as $postGroup)
                <div class="swiper-slide">
                    @forelse($postGroup as $key => $post)
                    <!-- Single Recent Reading Post Start -->
                    <div class="single-recent-reading-post" data-aos="fade-up">
                        <a class="recent-reading-post-thum" href="{{route('front.blog-details', [$post->post_slug])}}">
                            <img src="{{asset('storage/media/post/'. $post->post_image)}}" alt="">
                        </a>
                        <div class="recent-reading-post-content">
                            <div class="recent-reading-post-author">
                                By <a href="#">{{$post->user->name}}</a>
                            </div>
                            <h6 class="title"><a href="{{route('front.blog-details', [$post->post_slug])}}">{{Str::limit($post->post_title,40)}}</a></h6>
                            <div class="recent-reading-post-meta">
                                <span class="post-date">
                                    <i class="icofont-ui-calendar"></i>
                                    <a href="#">{{ Carbon\Carbon::parse($post->created_at)->toDayDateTimeString() }}</a>
                                </span>
                                <!-- <span>10 min read</span> -->
                            </div>
                        </div>
                    </div>
                    <!-- Single Recent Reading Post End -->
                    @empty
                    @endforelse
                </div>
                @empty
                @endforelse
            </div>
        </div>

    </div>
</div>
<!-- Recent Reading List Area End -->

<!-- Bottom Add Banner Area Start -->
<div class="bottom-add-banner-area section-space--pb_80">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <a href="#" class="bottom-add-banner-box" data-aos="fade-up">
                    <img src="{{asset('front_assets/images/banners/bottom-add-banner.jpg')}}" alt="">
                    <h6 class="bottom-add-text">Advertisement Section
                        <!-- <span>50% Off</span> -->
                    </h6>
                </a>
            </div>
        </div>
    </div>
</div> <!-- Bottom Add Banner Area End -->

@endsection