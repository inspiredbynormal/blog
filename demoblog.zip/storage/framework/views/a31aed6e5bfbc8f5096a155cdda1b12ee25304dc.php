

<?php $__env->startSection('content'); ?>

<!--====== Post Area Start ======-->
<section class="post-area post-area-list no-sidebar">
    <div class="container-fluid">
        <div class="post-area-inner">
            <!-- Entry Post -->
            <div class="entry-posts two-column masonary-posts row">
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-xl-3 col-lg-4 col-sm-6">
                    <div class="entry-post">
                        <div class="entry-thumbnail">
                            <img src="<?php echo e(asset('storage/media/post/'. $post->post_image)); ?>" alt="Image">
                        </div>
                        <div class="entry-content">
                            <h4 class="title">
                                <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>">
                                    <?php echo e(Str::limit($post->post_title, 25)); ?>

                                </a>
                            </h4>
                            <ul class="post-meta">
                                <li class="date">
                                    <p><?php echo e(Carbon\Carbon::parse($post->created_at)->toDayDateTimeString()); ?></p>

                                </li>
                                <li class="categories">
                                    <a href="<?php echo e(route('front.posts-by-category', $post->category->category_slug)); ?>"><?php echo e($post->category->category_name); ?></a>
                                </li>
                            </ul>
                            <p>
                                <?php echo e(Str::limit($post->post_short_desc, 100)); ?>

                            </p>
                            <a href="<?php echo e(route('front.blog-details', [$post->post_slug])); ?>" class="read-more">
                                Read More <i class="fas fa-long-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<!--====== Post Area End ======-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('front_script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog\resources\views/frontend/posts-by-category.blade.php ENDPATH**/ ?>