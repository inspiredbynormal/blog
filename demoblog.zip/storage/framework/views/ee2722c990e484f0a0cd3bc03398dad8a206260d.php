

<?php $__env->startSection('content'); ?>
<section class="shopping-login-page">
    <div class="container">
        <div class="login-wrapper">
            <div class="row no-gutters">
                <div class="col-lg-6 offset-lg-3">
                    <div class="login-box">
                        <div class="">
                            <?php if(session('msg')): ?>
                            <div class="alert alert-<?php echo e(session('type') == 'error' ? 'danger' : 'success'); ?>">
                                <?php echo e(session('msg')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="form-title">
                            <h3>Login</h3>
                        </div>
                        <form class="login-form" method="POST" action="<?php echo e(route('user-login-submit')); ?>">
                            <?php echo csrf_field(); ?>
                            <p>
                                <label for="email">Email address<span class="required">*</span></label>
                                <input type="text" id="email" name="email" value="<?php echo e(old('email')); ?>">
                            </p>
                            <p>
                                <label for="password">Password<span class="required">*</span></label>
                                <input type="password" id="password" name="password" autocomplete="off">
                            </p>
                            <p class="text-center">
                                <button type="submit" class="form-btn">Login</button>
                            </p>

                            <p>Not yet registered. </p>
                            <h6><a href="<?php echo e(route('user-register')); ?>">Register Now</a></h6>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\demoblog\resources\views/frontend/user/login.blade.php ENDPATH**/ ?>